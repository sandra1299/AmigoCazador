﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.DAL
{
    public class RepositorioRol : IRepositorio<Rol>
    {
        private string DBName = "AmigoCazador.db";
        private string TableName = "Rol";
        public List<Rol> Read
        {
            get
            {
                List<Rol> datos = new List<Rol>();
                using (var db = new LiteDatabase(DBName))
                {
                    datos = db.GetCollection<Rol>(TableName).FindAll().ToList();
                }
                return datos;
            }
        }

        public bool Create(Rol entidad)
        {
            entidad.Id = Guid.NewGuid().ToString();
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Rol>(TableName);
                    coleccion.Insert(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(string id)
        {
            try
            {
                int r;
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Rol>(TableName);
                    r = coleccion.Delete(e => e.Id == id);
                }
                return r > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Update(Rol entidad)
        {
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Rol>(TableName);
                    coleccion.Update(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
