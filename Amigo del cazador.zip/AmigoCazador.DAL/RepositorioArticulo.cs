﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.DAL
{
    public class RepositorioArticulo : IRepositorio<Articulo>
    {
        private string DBName = "AmigoCazador.db";
        private string TableName = "Articulo";
        public List<Articulo> Read
        {
            get
            {
                List<Articulo> datos = new List<Articulo>();
                using (var db = new LiteDatabase(DBName))
                {
                    datos = db.GetCollection<Articulo>(TableName).FindAll().ToList();
                }
                return datos;
            }
        }

        public bool Create(Articulo entidad)
        {
            entidad.Id = Guid.NewGuid().ToString();
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Articulo>(TableName);
                    coleccion.Insert(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(string id)
        {
            try
            {
                int r;
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Articulo>(TableName);
                    r = coleccion.Delete(e => e.Id == id);
                }
                return r > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Update(Articulo entidad)
        {
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<Articulo>(TableName);
                    coleccion.Update(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
