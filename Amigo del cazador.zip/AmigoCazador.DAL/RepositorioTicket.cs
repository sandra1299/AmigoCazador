﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using LiteDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.DAL
{
    public class RepositorioTicket : IRepositorio<InventarioVenta>
    {
        private string DBName = "Inventario.db";
        private string TableName = "Reportes";
        public List<InventarioVenta> Read
        {
            get
            {
                List<InventarioVenta> datos = new List<InventarioVenta>();
                using (var db = new LiteDatabase(DBName))
                {
                    datos = db.GetCollection<InventarioVenta>(TableName).FindAll().ToList();
                }
                return datos;
            }
        }

        public bool Create(InventarioVenta entidad)
        {
            entidad.Id = Guid.NewGuid().ToString();
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<InventarioVenta>(TableName);
                    coleccion.Insert(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(string id)
        {
            try
            {
                int r;
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<InventarioVenta>(TableName);
                    r = coleccion.Delete(e => e.Id == id);
                }
                return r > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Update(InventarioVenta entidad)
        {
            try
            {
                using (var db = new LiteDatabase(DBName))
                {
                    var coleccion = db.GetCollection<InventarioVenta>(TableName);
                    coleccion.Update(entidad);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
