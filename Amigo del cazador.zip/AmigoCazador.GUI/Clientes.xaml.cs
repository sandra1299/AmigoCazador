﻿using AmigoCazador.BIZ;
using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using AmigoCazador.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AmigoCazador.GUI
{
    /// <summary>
    /// Lógica de interacción para Clientes.xaml
    /// </summary>
    public partial class Clientes : UserControl
    {
        enum accion
        {
            nuevo,
            editar
        }
        IManejadorCliente manejadorCliente;

        accion clientes;

        public Clientes()
        {
            InitializeComponent();

            manejadorCliente = new ManejadorClientes(new RepositorioClientes());

            HabilitarBotones(false);

            LimpiarBotones();

            ActualizarTabla();
        }

        private void ActualizarTabla()
        {
            dtgUsuarios.ItemsSource = null;
            dtgUsuarios.ItemsSource = manejadorCliente.Leer;
        }

        private void LimpiarBotones()
        {
            txbUsuarioId.Text = "";
            txtNombreCliente.Clear();
            txtApellidosCliente.Clear();
            txtRFCCliente.Clear();
            txtDNICliente.Clear();
            txtCalleCliente.Clear();
            txtMunicipioCliente.Clear();
            txtEstadoCliente.Clear();
            txtTelefonoCliente.Clear();
            txtEmailCliente.Clear();
        }

        private void HabilitarBotones(bool habilitar)
        {
            btnNuevoCliente.IsEnabled = !habilitar;
            btnAgregarcliente.IsEnabled = habilitar;
            btnEditarCliente.IsEnabled = !habilitar;
            btnEliminarCliente.IsEnabled = !habilitar;
            btnCancelarcliente.IsEnabled = habilitar;
            btnCargarCliente.IsEnabled = !habilitar;
        }

        private void BtnNuevoCliente_Click(object sender, RoutedEventArgs e)
        {
            LimpiarBotones();
            HabilitarBotones(true);
            clientes = accion.nuevo;
        }

        private void BtnAgregarcliente_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNombreCliente.Text) || string.IsNullOrEmpty(txtApellidosCliente.Text) || string.IsNullOrEmpty(txtRFCCliente.Text) || string.IsNullOrEmpty(txtDNICliente.Text) || string.IsNullOrEmpty(txtCalleCliente.Text) || string.IsNullOrEmpty(txtMunicipioCliente.Text) || string.IsNullOrEmpty(txtEstadoCliente.Text))
            {
                MessageBox.Show("Faltan Datos por Ingresar\nVerifica los campos", "Clientes", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (clientes == accion.nuevo)
            {
                Cliente client = new Cliente()
                {
                    NombreCliente = txtNombreCliente.Text,
                    Apellidos = txtApellidosCliente.Text,
                    RFC = txtRFCCliente.Text,
                    DNI = txtDNICliente.Text,
                    Calle = txtCalleCliente.Text,
                    Municipio = txtMunicipioCliente.Text,
                    Estado = txtEstadoCliente.Text,
                    Telefono = txtTelefonoCliente.Text,
                    Email = txtEmailCliente.Text,
                };
                if (manejadorCliente.Agregar(client))
                {
                    MessageBox.Show("Cliente agregado correctamente", "Clientes", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarBotones();
                    ActualizarTabla();
                    HabilitarBotones(false);
                    ActualizarTabla();
                }
                else
                {
                    MessageBox.Show("El Cliente no pudo ser agregado", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                Cliente clint = dtgUsuarios.SelectedItem as Cliente;
                clint.NombreCliente = txtNombreCliente.Text;
                clint.Apellidos = txtApellidosCliente.Text;
                clint.RFC = txtRFCCliente.Text;
                clint.DNI = txtDNICliente.Text;
                clint.Calle = txtCalleCliente.Text;
                clint.Municipio = txtMunicipioCliente.Text;
                clint.Estado = txtEstadoCliente.Text;
                clint.Telefono = txtTelefonoCliente.Text;
                clint.Email = txtEmailCliente.Text;
                if (manejadorCliente.Modificar(clint))
                {
                    MessageBox.Show("Cliente modificado correctamente", "Clientes", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarBotones();
                    ActualizarTabla();
                    HabilitarBotones(false);
                    ActualizarTabla();
                }
                else
                {
                    MessageBox.Show("El Cliente no pudo ser actualizado", "Clientes", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnEditarCliente_Click(object sender, RoutedEventArgs e)
        {
            Cliente cliente = dtgUsuarios.SelectedItem as Cliente;
            if (cliente != null)
            {
                txbUsuarioId.Text = cliente.Id;
                txtNombreCliente.Text = cliente.NombreCliente;
                txtApellidosCliente.Text = cliente.Apellidos;
                txtRFCCliente.Text = cliente.RFC;
                txtDNICliente.Text = cliente.DNI;
                txtCalleCliente.Text = cliente.Calle;
                txtMunicipioCliente.Text = cliente.Municipio;
                txtEstadoCliente.Text = cliente.Estado;
                txtTelefonoCliente.Text = cliente.Telefono;
                txtEmailCliente.Text = cliente.Email;
                clientes = accion.editar;
                HabilitarBotones(true);
            }
        }

        private void BtnEliminarCliente_Click(object sender, RoutedEventArgs e)
        {
            Cliente clint = dtgUsuarios.SelectedItem as Cliente;
            if (clint != null)
            {
                if (MessageBox.Show("¿Lo deseas eliminar?", "Clientes", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    if (manejadorCliente.Eliminar(clint.Id))
                    {
                        MessageBox.Show("Exitosamente eliminado", "Clientes", MessageBoxButton.OK, MessageBoxImage.Information);
                        ActualizarTabla();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar usuario", "Clientes", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void BtnCancelarcliente_Click(object sender, RoutedEventArgs e)
        {
            LimpiarBotones();
            HabilitarBotones(false);
        }

        private void BtnCargarCliente_Click(object sender, RoutedEventArgs e)
        {
            ActualizarTabla();
        }
    }
}
