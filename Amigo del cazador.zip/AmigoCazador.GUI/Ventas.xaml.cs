﻿using AmigoCazador.BIZ;
using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using AmigoCazador.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AmigoCazador.GUI
{
    /// <summary>
    /// Lógica de interacción para Ventas.xaml
    /// </summary>
    public partial class Ventas : UserControl
    {
        Venta venta;
        enum accion
        {
            nuevo,
            editar
        }
        IManejadorVenta manejadorVenta;

        IManejadorUsuario manejadorUsuario;

        IManejadorCliente manejadorCliente;

        IManejadorArticulo manejadorArticulo;

        accion ventas;

        public int Cantidad { get; set; }
        public Ventas()
        {
            InitializeComponent();

            manejadorVenta = new ManejadorVenta(new RepositorioVenta());

            manejadorUsuario = new ManejadorUsuario(new RepositorioUsuario());

            manejadorCliente = new ManejadorClientes(new RepositorioClientes());

            manejadorArticulo = new ManejadorArticulo(new RepositorioArticulo());

            ActualizarBase();

            HabilitarBotones(false);

            LimpiarBotones();
        }

        private void LimpiarBotones()
        {
            txbUsuarioId.Text = "";
            txtCantidad.Clear();
        }

        private void HabilitarBotones(bool habilitar)
        {
            btnNuevoVentas.IsEnabled = !habilitar;
            btnEliminarVentas.IsEnabled = habilitar;
            btnCancelarVentas.IsEnabled = habilitar;
            btnVender.IsEnabled = habilitar;
            btnAgregar.IsEnabled = habilitar;
        }

        private void ActualizarBase()
        {
            cmbUsuario.ItemsSource = null;
            cmbUsuario.ItemsSource = manejadorUsuario.Leer;

            cmbClientes.ItemsSource = null;
            cmbClientes.ItemsSource = manejadorCliente.Leer;

            cmbArticulos.ItemsSource = null;
            cmbArticulos.ItemsSource = manejadorArticulo.Leer;
        }

        private void BtnNuevoVentas_Click(object sender, RoutedEventArgs e)
        {
            LimpiarBotones();
            HabilitarBotones(true);
            venta = new Venta();
            venta.ArtCompras = new List<Articulo>();
            ActualizarElVale();
            ventas = accion.nuevo;
        }

        private void ActualizarElVale()
        {
            dtgUsuarios.ItemsSource = null;
            dtgUsuarios.ItemsSource = venta.ArtCompras;
        }

        private void BtnEliminarVentas_Click(object sender, RoutedEventArgs e)
        {
            Articulo artic = dtgUsuarios.SelectedItem as Articulo;
            if (artic != null)
            {
                venta.ArtCompras.Remove(artic);
                ActualizarElVale();
            }
        }

        private void BtnCancelarVentas_Click(object sender, RoutedEventArgs e)
        {
            //dtgUsuarios.Items.Clear();
            LimpiarBotones();
            HabilitarBotones(false);
            ActualizarElVale();
        }

        private void BtnVender_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("El total de la compra es: 547", "Venta", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnAgregar_Click(object sender, RoutedEventArgs e)
        {
            Articulo artic = cmbArticulos.SelectedItem as Articulo;
            Venta v = new Venta();
            if (artic != null)
            {
                if (string.IsNullOrEmpty(txtCantidad.Text))
                {
                    MessageBox.Show("No ha llenado el Campo de cantidad", "Ventas", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                foreach (var item in txtCantidad.Text)
                {
                    if (!(char.IsNumber(item)))
                    {
                        MessageBox.Show("Valor invalido, intente de nuevo", "Ventas", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                v.Cantidad = int.Parse(txtCantidad.Text);
                v.Producto = artic.NombreArticulo;
                v.PrecioVenta = artic.PrecioVenta;
                v.Total = v.Cantidad * v.PrecioVenta;
                if (artic.Cantidad < int.Parse(txtCantidad.Text))
                {
                    MessageBox.Show("No hay suficientes productos", "Ventas", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                venta.ArtCompras.Add(artic);
                ActualizarElVale();
            }
            else
            {
                MessageBox.Show("No selecciono nada en la tabla", "Inventarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }
    }
}
