﻿using AmigoCazador.BIZ;
using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using AmigoCazador.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AmigoCazador.GUI
{
    /// <summary>
    /// Lógica de interacción para Usuarios.xaml
    /// </summary>
    public partial class Usuarios : UserControl
    {
        enum accion
        {
            nuevo,
            editar
        }
        IManejadorUsuario manejadorUsuarios;

        accion usuarios;

        public Usuarios()
        {
            InitializeComponent();

            manejadorUsuarios = new ManejadorUsuario(new RepositorioUsuario());

            HabilitarBotones(false);

            LimpiarBotones();

            ActualizarTabla();

        }

        private void ActualizarTabla()
        {
            dtgUsuarios.ItemsSource = null;
            dtgUsuarios.ItemsSource = manejadorUsuarios.Leer;
        }

        private void LimpiarBotones()
        {
            txbUsuarioId.Text = "";
            txtNombreUsuario.Clear();
            txtContraseñaUsuario.Clear();
        }

        private void HabilitarBotones(bool habilitar)
        {
            btnNuevoUsuario.IsEnabled = !habilitar;
            btnAgregarUsuario.IsEnabled = habilitar;
            btnEditarUsuario.IsEnabled = !habilitar;
            btnEliminarUsuraios.IsEnabled = !habilitar;
            btnCancelarUsuario.IsEnabled = habilitar;
            btnCargarUsuario.IsEnabled = !habilitar;
        }

        private void BtnNuevoUsuario_Click(object sender, RoutedEventArgs e)
        {
            LimpiarBotones();
            HabilitarBotones(true);
            usuarios = accion.nuevo;
        }

        private void BtnAgregarUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNombreUsuario.Text) || string.IsNullOrEmpty(txtContraseñaUsuario.Password))
            {
                MessageBox.Show("Faltan Datos por Ingresar\nVerifica los campos", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (usuarios == accion.nuevo)
            {
                Usuario usuar = new Usuario()
                {
                    NombreUsuario = txtNombreUsuario.Text,
                    Contraseña = txtContraseñaUsuario.Password,
                };
                if (manejadorUsuarios.Agregar(usuar))
                {
                    MessageBox.Show("Usuario agregado correctamente", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarBotones();
                    ActualizarTabla();
                    HabilitarBotones(false);
                    ActualizarTabla();
                }
                else
                {
                    MessageBox.Show("El Usuario no pudo ser agregado", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                Usuario usar = dtgUsuarios.SelectedItem as Usuario;
                usar.NombreUsuario = txtNombreUsuario.Text;
                usar.Contraseña = txtContraseñaUsuario.Password;
                if (manejadorUsuarios.Modificar(usar))
                {
                    MessageBox.Show("Usuario modificado correctamente", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarBotones();
                    ActualizarTabla();
                    HabilitarBotones(false);
                    ActualizarTabla();
                }
                else
                {
                    MessageBox.Show("El Usuario no pudo ser actualizado", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void BtnEditarUsuario_Click(object sender, RoutedEventArgs e)
        {
            Usuario usuario = dtgUsuarios.SelectedItem as Usuario;
            if (usuario != null)
            {
                txbUsuarioId.Text = usuario.Id;
                txtNombreUsuario.Text = usuario.NombreUsuario;
                txtContraseñaUsuario.Password = usuario.Contraseña;
                usuarios = accion.editar;
                HabilitarBotones(true);
            }
        }

        private void BtnEliminarUsuraios_Click(object sender, RoutedEventArgs e)
        {
            Usuario user = dtgUsuarios.SelectedItem as Usuario;
            if (user != null)
            {
                if (MessageBox.Show("¿Lo deseas eliminar?", "Usuarios", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    if (manejadorUsuarios.Eliminar(user.Id))
                    {
                        MessageBox.Show("Exitosamente eliminado", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Information);
                        ActualizarTabla();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar usuario", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void BtnCancelarUsuario_Click(object sender, RoutedEventArgs e)
        {
            LimpiarBotones();
            HabilitarBotones(false);
        }

        private void BtnCargarUsuario_Click(object sender, RoutedEventArgs e)
        {
            ActualizarTabla();
        }
    }
}
