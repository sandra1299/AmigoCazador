﻿using AmigoCazador.BIZ;
using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using AmigoCazador.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AmigoCazador.GUI
{
    /// <summary>
    /// Lógica de interacción para Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        IManejadorUsuario manejadorUsuario;
        public Login()
        {
            InitializeComponent();

            manejadorUsuario = new ManejadorUsuario(new RepositorioUsuario());

            ActualizarBase();
        }

        private void ActualizarBase()
        {
            cmbUsuario.ItemsSource = null;
            cmbUsuario.ItemsSource = manejadorUsuario.Leer;
        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            //Entrada directa -> Presentacion a = new Presentacion();
            //Entrada directa -> a.Show();
            //Entrada directa -> this.Close();

            if (cmbUsuario.Text == "")
            {
                MessageBox.Show("Seleccione un usuario", "Inicio", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (string.IsNullOrEmpty(pasword.Password))
            {
                MessageBox.Show("Ingrese la contraseña", "Inicio", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (cmbUsuario.SelectedItem != null)
            {
                Usuario b = cmbUsuario.SelectedItem as Usuario;
                if(pasword.Password == b.Contraseña)
                {
                    MainWindow a = new MainWindow();
                    a.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("No ha seleccionado ningun usuario", "Inicio", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("¿Estas seguro?", "Inicio", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }
    }
}
