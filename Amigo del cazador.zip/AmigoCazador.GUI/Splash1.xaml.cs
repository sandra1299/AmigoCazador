﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AmigoCazador.GUI
{
    /// <summary>
    /// Lógica de interacción para Splash1.xaml
    /// </summary>
    public partial class Splash1 : Window
    {
        public Splash1()
        {
            InitializeComponent();
            metodo();
            Op.ValueChanged += siguinete;
        }

        private void siguinete(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Op.Value == 100)
            {
                Login a = new Login();
                a.Show();
                this.Close();
            }
        }

        private void metodo()
        {
            Duration tiempo = new Duration(TimeSpan.FromSeconds(6));
            DoubleAnimation animacion = new DoubleAnimation(100.0, tiempo);
            Op.BeginAnimation(System.Windows.Controls.Primitives.RangeBase.ValueProperty, animacion);
        }
    }
}
