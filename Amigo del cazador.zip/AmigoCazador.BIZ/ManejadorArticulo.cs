﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorArticulo : IManejadorArticulo
    {
        IRepositorio<Articulo> articulo;
        public ManejadorArticulo(IRepositorio<Articulo> articulo)
        {
            this.articulo = articulo;
        }

        public List<Articulo> Leer => articulo.Read.OrderBy(p => p.NombreArticulo).ToList();

        public bool Agregar(Articulo entidad)
        {
            return articulo.Create(entidad);
        }

        public Articulo Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return articulo.Delete(id);
        }

        public bool Modificar(Articulo entidad)
        {
            return articulo.Update(entidad);
        }
    }
}
