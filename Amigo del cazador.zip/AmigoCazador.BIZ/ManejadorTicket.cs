﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorTicket : IManejadorTicket
    {
        IRepositorio<InventarioVenta> ticket;

        public ManejadorTicket(IRepositorio<InventarioVenta> tickets)
        {
            ticket = tickets;
        }
        public List<InventarioVenta> Leer => ticket.Read;

        public bool Agregar(InventarioVenta entidad)
        {
            return ticket.Create(entidad);
        }

        public InventarioVenta Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return ticket.Delete(id);
        }

        public bool Modificar(InventarioVenta entidad)
        {
            return ticket.Update(entidad);
        }
    }
}
