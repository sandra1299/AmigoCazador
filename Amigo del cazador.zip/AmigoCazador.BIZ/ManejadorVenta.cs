﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorVenta : IManejadorVenta
    {
        IRepositorio<Venta> venta;
        public ManejadorVenta(IRepositorio<Venta> venta)
        {
            this.venta = venta;
        }
        public List<Venta> Leer => venta.Read.OrderBy(p => p.Producto).ToList();

        public bool Agregar(Venta entidad)
        {
            return venta.Create(entidad);
        }

        public Venta Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return venta.Delete(id);
        }

        public bool Modificar(Venta entidad)
        {
            return venta.Update(entidad);
        }
    }
}
