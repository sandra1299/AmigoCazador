﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorRol : IManejadorRol
    {
        IRepositorio<Rol> rol;
        public ManejadorRol(IRepositorio<Rol> rol)
        {
            this.rol = rol;
        }
        public List<Rol> Leer => rol.Read.OrderBy(p => p.Nivel).ToList();

        public bool Agregar(Rol entidad)
        {
            return rol.Create(entidad);
        }

        public Rol Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return rol.Delete(id);
        }

        public bool Modificar(Rol entidad)
        {
            return rol.Update(entidad);
        }
    }
}
