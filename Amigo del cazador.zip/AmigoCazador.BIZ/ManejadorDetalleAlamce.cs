﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorDetalleAlamce : IManejadorDetalleAlmacen
    {
        IRepositorio<DetalleAlmacen> detalleAlmacen;
        public ManejadorDetalleAlamce(IRepositorio<DetalleAlmacen> detalleAlamcen)
        {
            this.detalleAlmacen = detalleAlamcen;
        }
        public List<DetalleAlmacen> Leer => detalleAlmacen.Read.OrderBy(p => p.Stock).ToList();

        public bool Agregar(DetalleAlmacen entidad)
        {
            return detalleAlmacen.Create(entidad);
        }

        public DetalleAlmacen Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return detalleAlmacen.Delete(id);
        }

        public bool Modificar(DetalleAlmacen entidad)
        {
            return detalleAlmacen.Update(entidad);
        }
    }
}
