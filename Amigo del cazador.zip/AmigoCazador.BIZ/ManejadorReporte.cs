﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorReporte : IManejadorReporte
    {
        IRepositorio<Reporte> reporte;
        public ManejadorReporte(IRepositorio<Reporte> reporte)
        {
            this.reporte = reporte;
        }
        public List<Reporte> Leer => reporte.Read.OrderBy(p => p.FolioReporte).ToList();

        public bool Agregar(Reporte entidad)
        {
            return reporte.Create(entidad);
        }

        public Reporte Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return reporte.Delete(id);
        }

        public bool Modificar(Reporte entidad)
        {
            return reporte.Update(entidad);
        }
    }
}
