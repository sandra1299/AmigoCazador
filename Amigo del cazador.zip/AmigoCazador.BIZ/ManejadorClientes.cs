﻿using AmigoCazador.COMMON.Entidades;
using AmigoCazador.COMMON.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmigoCazador.BIZ
{
    public class ManejadorClientes : IManejadorCliente
    {
        IRepositorio<Cliente> cliente;
        public ManejadorClientes(IRepositorio<Cliente> cliente)
        {
            this.cliente = cliente;
        }
        public List<Cliente> Leer => cliente.Read.OrderBy(p => p.NombreCliente).ToList();

        public bool Agregar(Cliente entidad)
        {
            return cliente.Create(entidad);
        }

        public Cliente Buscador(string Id)
        {
            return Leer.Where(e => e.Id == Id).SingleOrDefault();
        }

        public bool Eliminar(string id)
        {
            return cliente.Delete(id);
        }

        public bool Modificar(Cliente entidad)
        {
            return cliente.Update(entidad);
        }
    }
}
