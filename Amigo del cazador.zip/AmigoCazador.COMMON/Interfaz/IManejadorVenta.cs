﻿using AmigoCazador.COMMON.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Interfaz
{
    public interface IManejadorVenta:IManejadorGenerico<Venta>
    {
    }
}
