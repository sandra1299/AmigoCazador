﻿using AmigoCazador.COMMON.Entidades;

namespace AmigoCazador.COMMON.Interfaz
{
    public interface IManejadorArticulo:IManejadorGenerico<Articulo>
    {

    }
}
