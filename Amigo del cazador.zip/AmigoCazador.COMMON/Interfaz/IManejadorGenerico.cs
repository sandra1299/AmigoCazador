﻿using AmigoCazador.COMMON.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Interfaz
{
    public interface IManejadorGenerico<T> where T:Base
    {
        bool Agregar(T entidad);
        List<T> Leer { get; }
        bool Eliminar(string id);
        bool Modificar(T entidad);
        T Buscador(string Id);
    }
}
