﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public abstract class Base
    {
        public string Id { get; set; }
    }
}
