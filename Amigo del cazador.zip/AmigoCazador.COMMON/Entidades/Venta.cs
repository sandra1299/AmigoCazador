﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Venta:Base
    {
        //public DateTime? FechaHora { get; set; }
        public int Cantidad { get; set; }
        public string Producto { get; set; }
        public List<Articulo> ArtCompras { get; set; }
        //public Usuario Vendedor { get; set; }
        //public Cliente Comprador { get; set; }
        public float Total { get; set; }
        public float PrecioVenta { get; set; }
    }
}
