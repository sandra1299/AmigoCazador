﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Articulo:Base
    {
        public string NombreArticulo { get; set; }
        public string Marca { get; set; }
        public float Calibre { get; set; }
        public float Gramos { get; set; }
        public int Cantidad { get; set; }
        public float PrecioVenta { get; set; }
        public string Descripcion { get; set; }
        public byte[] Imagen { get; set; }
        public override string ToString()
        {
            return NombreArticulo;
        }
    }
}
