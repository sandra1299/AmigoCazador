﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class DetalleAlmacen:Base
    {
        public int Stock { get; set; }
        public char DescripcioAlma { get; set; }
        public DateTime? UltimoAbastece { get; set; }
    }
}
