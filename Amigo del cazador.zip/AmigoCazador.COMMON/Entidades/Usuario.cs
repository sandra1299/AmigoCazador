﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Usuario:Base
    {
        public string NombreUsuario { get; set; }
        public string Contraseña { get; set; }
        public override string ToString()
        {
            return NombreUsuario;
        }
    }
}
