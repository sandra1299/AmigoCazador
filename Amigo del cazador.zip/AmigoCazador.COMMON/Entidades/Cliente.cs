﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Cliente:Base
    {
        public string NombreCliente { get; set; }
        public string Apellidos { get; set; }
        public string RFC { get; set; }
        public string DNI { get; set; }
        public string Calle { get; set; }
        public string Municipio { get; set; }
        public string Estado { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public override string ToString()
        {
            return NombreCliente;
        }
    }
}
