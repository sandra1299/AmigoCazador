﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Rol:Base
    {
        public char Nivel { get; set; }
        public char Descripcion { get; set; }
    }
}
