﻿namespace AmigoCazador.COMMON.Entidades
{
    internal class SqlConnection
    {
        private string v;

        public SqlConnection(string v)
        {
            this.v = v;
        }
    }
}