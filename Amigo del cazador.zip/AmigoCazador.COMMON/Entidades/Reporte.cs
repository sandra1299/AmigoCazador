﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AmigoCazador.COMMON.Entidades
{
    public class Reporte:Base
    {
        public int FolioReporte { get; set; }

    }
}
